import React from "react";
import { MainRoutes } from "./Pages/mainRoutes";

const App = () => {
  return (
    <>
      <MainRoutes />
    </>
  );
};

export { App };
